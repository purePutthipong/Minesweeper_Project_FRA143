#ifndef GAME_H
#define GAME_H

#include <vector>
#include <memory>
#include <utility>
#include "GameObject.h"

class Game
{
private:
    int width, height, mines;
    int flagsUsed;
    int score;
    bool gameOver;
    bool firstClick = true;
    std::pair<int, int> explodedCell;
    std::vector<std::vector<std::shared_ptr<GameObject>>> board;

    void placeMines(int safeX, int safeY);
    void calculateAdjacency();
    int countAdjacentMines(int x, int y);
    void revealEmpty(int x, int y);

public:
    Game(int w, int h, int m);
    bool revealCell(int x, int y);
    void toggleFlag(int x, int y);
    bool isValid(int x, int y) const;
    bool isWin() const;
    void printBoard(bool revealAll = false) const;
    int getScore() const;
    bool isGameOver() const;
};

#endif
