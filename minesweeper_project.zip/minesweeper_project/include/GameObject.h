#ifndef GAME_OBJECT_H
#define GAME_OBJECT_H

class GameObject
{
public:
    virtual ~GameObject() {}
    virtual bool reveal() = 0;
    virtual bool isMine() const = 0;
    virtual void toggleFlag() = 0;
    virtual bool isRevealed() const = 0;
    virtual bool isFlagged() const = 0;
    virtual int getAdjacentMines() const = 0;
    virtual void setAdjacentMines(int count) = 0;
};

#endif
