#ifndef CELL_H
#define CELL_H

#include "GameObject.h"

class Cell : public GameObject
{
protected:
    bool mine;
    int adjacentMines;
    bool revealed;
    bool flagged;

public:
    Cell();
    virtual ~Cell();

    virtual bool reveal() override;
    virtual bool isMine() const override;
    virtual void toggleFlag() override;
    virtual bool isRevealed() const override;
    virtual bool isFlagged() const override;
    virtual int getAdjacentMines() const override;
    virtual void setAdjacentMines(int count) override;
    void setMine(bool m);
};

#endif
