#ifndef MINE_CELL_H
#define MINE_CELL_H

#include "Cell.h"

class MineCell : public Cell
{
public:
    MineCell();
    virtual bool reveal() override;
};

#endif
