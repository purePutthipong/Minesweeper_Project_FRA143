#include "Game.h"
#include <iostream>
#include <limits>
#include <sstream>

int main()
{
    int width, height, mines;

    std::cout << "==== MINESWEEPER ====\n";
    std::cout << "Select difficulty:\n";
    std::cout << "1. Easy (8x8, 10 mines)\n";
    std::cout << "2. Medium (12x12, 20 mines)\n";
    std::cout << "3. Hard (16x16, 40 mines)\n";
    std::cout << "Choice: ";
    int choice;
    while (true)
    {
        std::cout << "Choice: ";
        std::cin >> choice;

        if (choice == 1)
        {
            width = height = 8, mines = 10;
            break;
        }
        else if (choice == 2)
        {
            width = height = 12, mines = 20;
            break;
        }
        else if (choice == 3)
        {
            width = height = 16, mines = 40;
            break;
        }
        else
            std::cout << "Invalid input. Try again.\n";
    }

    Game game(width, height, mines);

    while (!game.isGameOver() && !game.isWin())
    {
        game.printBoard();
        std::cout << "Enter command (r x y = reveal, f x y = flag): ";

        std::string line;
        std::getline(std::cin >> std::ws, line); // อ่านทั้งบรรทัด

        std::istringstream iss(line);
        char cmd;
        int y, x;

        if (!(iss >> cmd >> y >> x))
        {
            std::cout << "Invalid command format. Please try again, e.g. r 1 2 or f 0 3\n";
            continue;
        }

        if (!game.isValid(x, y))
        {
            std::cout << "Invalid position. Coordinates out of bounds.\n";
            continue;
        }

        if (cmd == 'r')
            game.revealCell(x, y);
        else if (cmd == 'f')
            game.toggleFlag(x, y);
        else
            std::cout << "Unknown command. Please use 'r' to reveal or 'f' to flag.\n";
    }

    game.printBoard(true);
    if (game.isGameOver())
        std::cout << "\033[You hit a mine! Game Over!\n\033[0m";
    else
        std::cout << "\033[Congratulations! You win!\n\033[0m";

    std::cout << "Your Score: " << game.getScore() << " points\n";
    return 0;
}
