#include "Cell.h"

Cell::Cell() : mine(false), adjacentMines(0), revealed(false), flagged(false) {}

Cell::~Cell() {}

bool Cell::reveal()
{
    if (!flagged)
        revealed = true;
    return mine;
}

bool Cell::isMine() const { return mine; }
void Cell::toggleFlag()
{
    if (!revealed)
        flagged = !flagged;
}
bool Cell::isRevealed() const { return revealed; }
bool Cell::isFlagged() const { return flagged; }
int Cell::getAdjacentMines() const { return adjacentMines; }
void Cell::setAdjacentMines(int count) { adjacentMines = count; }
void Cell::setMine(bool m) { mine = m; }
