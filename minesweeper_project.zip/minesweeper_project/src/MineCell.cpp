#include "MineCell.h"

MineCell::MineCell()
{
    setMine(true);
}

bool MineCell::reveal()
{
    revealed = true;
    return true;
}
